###  Tox Protocol Plugin For Pidgin / libpurple

Please visit http://tox.dhs.org/ for general information and build instructions.
